import React from 'react'
import Card from 'react-bootstrap/Card';
import CardDeck from 'react-bootstrap/CardDeck';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Nav from 'react-bootstrap/Nav';


const LeftBar = ({ books }) => {
    return (
<div>
<Navbar collapseOnSelect expand="lg" bg="dark" variant="dark" className="flex-column">

    <Nav className="mr-auto">
      <li><Nav.Link href="/features">Author</Nav.Link>
      <Nav.Link href="/pricing">My Books</Nav.Link></li>
    </Nav>
    </Navbar>
</div>
    )
  };
export default LeftBar

//className="flex-column"