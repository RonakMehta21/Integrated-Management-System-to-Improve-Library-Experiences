import React, { Component } from 'react';
import { Route } from 'react-router-dom';
import index from './index';
import search from './search';
import newpage from './newpage';

class main extends Component {
	render() {
		return (
			<div>
			<Route path="/" exact={true} component={index}/>
			<Route path="/search" exact={true} component={search}/>
			<Route path="/newpage" exact={true} component={newpage}/>
			</div>
		)
	}
}

export default main;


